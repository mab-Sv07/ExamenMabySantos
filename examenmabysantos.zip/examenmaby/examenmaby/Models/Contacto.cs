﻿using System;
using System.Collections.Generic;
using System.Text;
using SQLite;

namespace examenmaby.Models
{
    public class Contacto
    {
        public string Nombres { get; set; }
        public string Apellidos { get; set; }
        public int Edad { get; set; }
        public string País { get; set; }
        public string Nota { get; set; }
        public double Latitud { get; set; }
        public double Longitud { get; set; }
        public byte[] Imagen { get; set; }

    }
}
