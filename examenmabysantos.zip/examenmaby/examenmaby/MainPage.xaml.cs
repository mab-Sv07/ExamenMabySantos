﻿using examenmaby.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace examenmaby
{
    public partial class MainPage : ContentPage
    {
        private Entry nombresEntry;
        private Entry apellidosEntry;
        private Entry edadEntry;
        private Entry paísEntry;
        private Entry notaEntry;
        private Button agregarButton;

        public MainPage()
        {
           
            nombresEntry = new Entry();
            apellidosEntry = new Entry();
            edadEntry = new Entry();
            paísEntry = new Entry();
            notaEntry = new Entry();

           
            agregarButton = new Button { Text = "Agregar" };
            agregarButton.Clicked += AgregarButton_Clicked;

         
            Appearing += MainPage_Appearing;

        
            Content = new StackLayout
            {
                Children =
            {
                nombresEntry,
                apellidosEntry,
                edadEntry,
                paísEntry,
                notaEntry,
                agregarButton
            }
            };
        }

        private void MainPage_Appearing(object sender, EventArgs e)
        {
            
        }

        private void AgregarButton_Clicked(object sender, EventArgs e)
        {
           
            string nombres = nombresEntry.Text;
            string apellidos = apellidosEntry.Text;
            int edad = int.Parse(edadEntry.Text);
            string país = paísEntry.Text;
            string nota = notaEntry.Text;

            Contacto contacto = new Contacto
            {
                Nombres = nombres,
                Apellidos = apellidos,
                Edad = edad,
                País = país,
                Nota = nota
            };

            
        }
    }
    
}
