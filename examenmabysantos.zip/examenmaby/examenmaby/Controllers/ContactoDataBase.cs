﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.SqlTypes;
using System.Text;
using System.Threading.Tasks;
using examenmaby.Models;
using SQLite;


namespace examenmaby.Controllers.ContactoDatabase
{


public class ContactosDatabase
    {
        readonly SQLiteConnection database;

        public ContactosDatabase(string dbPath)
        {
            database = new SQLiteConnection(dbPath);
            database.CreateTable<Contacto>();
        }

        public List<Contacto> ObtenerContactos()
        {
            return database.Table<Contacto>().ToList();
        }

        public int InsertarContacto(Contacto contacto)
        {
            return database.Insert(contacto);
        }

        public int ActualizarContacto(Contacto contacto)
        {
            return database.Update(contacto);
        }

        public int EliminarContacto(Contacto contacto)
        {
            return database.Delete(contacto);
        }
        public Task<Models.Contacto> GetContacto(int pid)
        {
            return Contacto.Table< Models.Contacto>().Where(i => i.Id == pid).FirstOrDefaultAsync();
        }
    }

}
