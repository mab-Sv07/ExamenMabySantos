﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace examenmaby.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class Pagecontactos : ContentPage
    {
        // Variable que guardara la foto 
        Plugin.Media.Abstractions.MediaFile photo = null;
        public Pagecontactos()
        {
            InitializeComponent();
        }
        public byte[] GetImageToBytes()
        {
            if (photo != null)
            {
                using (MemoryStream memory = new MemoryStream())
                {
                    Stream stream = photo.GetStream();
                    stream.CopyTo(memory);
                    byte[] bytes = memory.ToArray();

                    return bytes;
                }
            }

            return null;
        }


        private async void btnproceso_Clicked(object sender, EventArgs e)
        {
            if (Nombres.Text == null)
            {
                await DisplayAlert("ALERTA", "DEBES ESCRIBIR UN NOMBRE", "OK");
                Nombres.Focus();
            }
            if (Nombres.Text == null)
            {
                await DisplayAlert("ALERTA", "DEBES ESCRIBIR UN APELLIDO", "OK");
                Apellidos.Focus();
            }
            else if (Edad.Text == null)
            {
                await DisplayAlert("ALERTA", "DEBES ESCRIBIR UN TELEFONO", "OK");
                Edad.Focus();
            }
            else if (Pais.Text == null)
            {
                await DisplayAlert("ALERTA", "DEBES ESCRIBIR UN PAIS", "OK");
                Pais.Focus();
            }
            else if (Nota.Text == null)
            {
                await DisplayAlert("ALERTA", "DEBES ESCRIBIR UNA NOTA", "OK");
                Nota.Focus();
            }

            else
            {


                var contacto = new Models.Contacto
                {
                    Nombres = Nombres.Text,
                    Apellidos = Apellidos.Text,
                    Edad = Convert.ToInt32(Edad.Text),
                    País = Pais.Text,
                    Nota = Nota.Text,
                    Imagen = GetImageToBytes()
                };

                if (await App.contacto.AddContacto(contacto) > 0)
                {
                    await DisplayAlert("Aviso", "Contacto guardado correctamente", "OK");
                }
                else
                {
                    await DisplayAlert("Aviso", "No se pudo guardar", "OK");
                    limpiar();
                    var page = new Views.Pageresultados();
                    //page.BindingContext = result;
                    await Navigation.PushAsync(page);
                }

            }
        }
        private async void btnImagenClicked(object sender, EventArgs e)
        {
            photo = await CrossMedia.Current.TakePhotoAsync(new Plugin.Media.Abstractions.StoreCameraMediaOptions
            {
                Directory = "APP",
                Name = "foto.jpg",
                SaveToAlbum = true
            });

            if (photo != null)
            {
                Imagen.Source = ImageSource.FromStream(() => { return photo.GetStream(); });
            }
        }
        private void limpiar()
        {
            Nombres.Text = "";
            Apellidos.Text = "";
            Edad.Text = "";
            Pais.Text = ""; Nota.Text = "";

        }

    }
}