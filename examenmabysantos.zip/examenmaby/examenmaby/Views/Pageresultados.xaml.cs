﻿using examenmaby.Controllers.ContactoDatabase;
using examenmaby.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace examenmaby.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class Pageresultados : ContentPage
    {
        public Pageresultados()
        {
            InitializeComponent();
        }
       

public class ListaContactosPage : ContentPage
    {
        ListView contactosListView;

        public ListaContactosPage()
        {
         
            List<Contacto> contactos = ObtenerTodosLosContactos();

       
            contactosListView = new ListView
            {
                ItemsSource = contactos,
                ItemTemplate = new DataTemplate(() =>
                {
                 
                    Image imagen = new Image();
                    imagen.SetBinding(Image.SourceProperty, "Imagen");

                    Label nombresLabel = new Label();
                    nombresLabel.SetBinding(Label.TextProperty, "Nombres");

                    Label apellidosLabel = new Label();
                    apellidosLabel.SetBinding(Label.TextProperty, "Apellidos");

                 
                    return new ViewCell
                    {
                        View = new StackLayout
                        {
                            Orientation = StackOrientation.Horizontal,
                            Children = { imagen, nombresLabel, apellidosLabel }
                        }
                    };
                })
            };

         
            Content = contactosListView;
        }

        List<Contacto> ObtenerTodosLosContactos()
        {

            ContactosDatabase database = new ContactosDatabase(App.DatabasePath);
            List<Contacto> contactos = database.ObtenerContactos();

            return contactos;
        }
    }

}
}