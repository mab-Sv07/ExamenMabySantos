﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace examenmaby.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class Pagelistcontactos : ContentPage
    {
        public Pagelistcontactos()
        {
            InitializeComponent();
        }
        protected override async void OnAppearing()
        {
            base.OnAppearing();

            try
            {
                Pagelistcontactos.ItemsSource = await App.ContactosDatabase.GetAllContacto();
            }
            catch (Exception ex)
            {
                ex.ToString();
            }

        }
        private void ToolbarItem_Clicked(object sender, EventArgs e)
        {
            var page = new Views.Pagecontactos();
            Navigation.PushAsync(page);
        }
    }
}